<?php
$txt = "Hello world!";
$x = 5;
$y = 10.5;
echo $txt;
echo "The result of $x + $y is" . $coLOR . "<br>";
?>