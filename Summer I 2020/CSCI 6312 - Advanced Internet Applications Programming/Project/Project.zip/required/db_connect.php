<?php
require_once 'db_config.php'; //tell the script that file is in this folder (not in this script)
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
?>