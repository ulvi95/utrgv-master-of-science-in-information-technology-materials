<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'u551001383_project');
define('DB_PASSWORD', 'Qwer1234');
define('DB_DATABASE', 'u551001383_team');
?>